package util;

public class incorrectROMExtensionException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8585961056957613650L;

	public incorrectROMExtensionException(String errorMessage) {
		super(errorMessage);
	}
}
