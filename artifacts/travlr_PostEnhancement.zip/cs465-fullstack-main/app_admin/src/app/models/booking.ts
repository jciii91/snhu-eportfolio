export class Booking {
    tripCode!: string;
    travelerID!: string;
    agentID!: string;
}
