export class User {
    email!: string;
    name!: string;
    role?: string;
    membershipID?: string;
}
